@echo off
cd /d "%~dp0resources"
py -3 --version >nul 2>&1
if %errorlevel% equ 0 (
    py -3 download_home_assets.py --open
) else (
    python --version >nul 2>&1
    if errorlevel 1 (
        echo Python 3 is required. Install Python 3, then run this launcher again.
        pause
        exit /b 1
    )
    python download_home_assets.py --open
)
if errorlevel 1 pause
