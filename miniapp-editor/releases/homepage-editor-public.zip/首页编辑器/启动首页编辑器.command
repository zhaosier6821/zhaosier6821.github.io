#!/bin/sh
cd -- "$(dirname -- "$0")/resources" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  printf '%s\n' '需要 Python 3。请安装 Python 3 后再运行。'
  read -r _answer
  exit 1
fi
python3 download_home_assets.py --open
_result=$?
if [ "$_result" -ne 0 ]; then
  printf '%s\n' '原图未下载齐，尚未生成离线首页编辑器。上方有具体失败地址。'
  read -r _answer
fi
exit "$_result"
