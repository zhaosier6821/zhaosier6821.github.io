#!/usr/bin/env python3
"""Download the 24 real homepage images and build a self-contained editor.

Uses the configured HTTPS proxy and normal TLS certificate verification.
No browser embedding, CORS changes, VPN, or credential extraction is involved.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import base64
import hashlib
import json
import re
import sys
import webbrowser

ROOT = Path(__file__).resolve().parent

def valid_image(data):
    return (data.startswith(b'\x89PNG\r\n\x1a\n') or data.startswith(b'\xff\xd8\xff')
            or data.startswith((b'GIF87a', b'GIF89a'))
            or (data.startswith(b'RIFF') and data[8:12] == b'WEBP')
            or b'ftypavif' in data[:32])

def download(asset, cache):
    url = asset['url']
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname != 'osscdn.dd1x.cn':
        raise ValueError('Unexpected origin in homepage asset manifest')
    target = cache / Path(asset['path']).name
    if target.exists():
        data = target.read_bytes()
        if (asset['kind'] == 'image' and valid_image(data)) or (asset['kind'] == 'font' and data[:4] in (b'wOFF', b'wOF2')):
            return asset, data, 'cached'
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0 MiniStudio/1.1', 'Accept': 'image/*,*/*;q=0.8'})
    with urlopen(request, timeout=30) as response:
        if response.status != 200:
            raise ValueError('Image origin returned HTTP ' + str(response.status))
        if urlsplit(response.url).hostname != 'osscdn.dd1x.cn':
            raise ValueError('Unexpected asset redirect origin')
        data = response.read(20 * 1024 * 1024 + 1)
    if not data or len(data) > 20 * 1024 * 1024:
        raise ValueError('Empty asset or asset larger than 20MB')
    if asset['kind'] == 'image' and not valid_image(data):
        raise ValueError('Response is not a supported image')
    if asset['kind'] == 'font' and data[:4] not in (b'wOFF', b'wOF2'):
        raise ValueError('Response is not a WOFF font')
    target.write_bytes(data)
    return asset, data, 'downloaded'

def main():
    parser = argparse.ArgumentParser(description='Download original homepage images and build offline editor')
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--list', action='store_true', help='List required URLs without accessing network')
    parser.add_argument('--open', action='store_true', help='Open the completed editor in the default browser')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'home-assets-manifest.json').read_text(encoding='utf-8'))
    if args.list:
        for asset in manifest['assets']:
            print(asset['kind'], asset['url'])
        return 0
    cache = ROOT / '.original-assets-cache'
    cache.mkdir(exist_ok=True)
    image_cache_complete = all((cache / Path(a['path']).name).exists() and valid_image((cache / Path(a['path']).name).read_bytes()) for a in manifest['assets'] if a['kind'] == 'image')
    assets = [a for a in manifest['assets'] if not (image_cache_complete and a['kind'] == 'font' and not (cache / Path(a['path']).name).exists())]
    downloaded, errors, optional = {}, [], []
    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, 6))) as pool:
        jobs = {pool.submit(download, asset, cache): asset for asset in assets}
        for job in as_completed(jobs):
            asset = jobs[job]
            try:
                record, data, action = job.result()
                downloaded[record['url']] = (record, data)
                print(f'OK {action}: {Path(record["path"]).name}', flush=True)
            except Exception as error:
                message = f'{asset["url"]}: {error}'
                (errors if asset['kind'] == 'image' else optional).append(message)
                print('FAILED ' + message, file=sys.stderr, flush=True)
    if errors:
        print(f'\nIncomplete: {len(errors)} homepage images unavailable. No finished offline editor was generated.', file=sys.stderr)
        print('Allow osscdn.dd1x.cn in cloud environment settings, or run this script on a computer that can open the original images.', file=sys.stderr)
        return 1
    output_manifest = {**manifest, 'assets': []}
    embedded = {}
    with ZipFile(ROOT / 'home-original-assets.zip', 'w', ZIP_DEFLATED) as archive:
        for asset, data in downloaded.values():
            archive.writestr(asset['path'], data)
            output_manifest['assets'].append({**asset, 'sha256': hashlib.sha256(data).hexdigest()})
            embedded[asset['url']] = {'type': asset['type'], 'base64': base64.b64encode(data).decode('ascii')}
        archive.writestr('manifest.json', json.dumps(output_manifest, ensure_ascii=False, indent=2))
    script = 'window.MINI_STUDIO_ORIGINAL_ASSETS = ' + json.dumps(embedded, separators=(',', ':')) + ';\n'
    template = (ROOT / 'homepage-editor.html').read_text(encoding='utf-8')
    final, replacements = re.subn(r'<script>\s*window\.MINI_STUDIO_ORIGINAL_ASSETS\s*=.*?</script>', lambda _: '<script>' + script + '</script>', template, count=1, flags=re.S)
    if replacements != 1:
        raise ValueError('Offline editor template does not contain the original-asset slot')
    (ROOT / 'original-assets.js').write_text(script, encoding='utf-8')
    (ROOT / 'homepage-editor-offline.html').write_text(final, encoding='utf-8')
    print('\nReady: 24 real homepage images cached. Open homepage-editor-offline.html.')
    if optional:
        print('Optional font unavailable; the preview will use a system font.')
    if args.open:
        webbrowser.open((ROOT / 'homepage-editor-offline.html').as_uri())
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
